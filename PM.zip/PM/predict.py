#predict.py
import pypyodbc
import operator
import math
import sys
import os

def avg(array):
    s=0
    for k in array:
        s=s+k
    return round(s/len(array))

def classify(datalist):
    datalist_v=[]
    for data in datalist:
        if type(data)==type(1):
            datalist_v.append(data)
    _min=min(datalist_v)
    _max=max(datalist_v)
    _num=len(datalist_v)
    R=_max-_min
    K=round(1.87*((_num-1)**0.4))
    d = round(R / K)
    axis = []
    _sum=[]
    for m in range(0, K):
        axis.append(_min + m * d)
        _sum.append([])
    resultlist=[]
    for data in datalist:
        if type(data)==type(1):
            state=0
            for k in range(0,K-1):
                if data<axis[k+1] and state==0:
                    resultlist.append(k)
                    _sum[k].append(data)
                    state=1
            if state==0:
                resultlist.append(K-1)
                _sum[K-1].append(data)
        else:
            resultlist.append('None')

    averagelist=[]
    numlist=[]
    for index in range(len(_sum)):
        if len(_sum[index])==0:
            if index==len(_sum)-1:
                average=axis[index]
            else:
                average=avg([axis[index],axis[index+1]])
        else:
            average=avg(_sum[index])
        numlist.append(len(_sum[index]))
        averagelist.append(average)

    return resultlist,averagelist,numlist

if __name__=="__main__":
    conn_sql = 'Driver={Microsoft Access Driver (*.mdb)};DBQ=F:\PM\Database_1.mdb'
    conn = pypyodbc.win_connect_mdb(conn_sql)
    #conn = pypyodbc.connect(str)
    cur = conn.cursor()
    list_dish=[]
    cur.execute("select name from MSysObjects where type=1 and flags=0")
    predict=[]
    for table in cur.fetchall():
        list_dish.append(table[0])

    def bayes_predict(person,dishID,list_dish):
        print(person[-1])
        personID=int(person[-1])-1
        rowlist_c=[]
        sql='select * from '+dishID
        cur.execute(sql)
        for row in cur.fetchall():
            if type(row[2])==type(1.0):
                rowlist_c.append(list(row)[5:])
        for row in rowlist_c:
            rs=classify(row)
            category=rs[0]
            avg=rs[1]
            num=rs[2]

            cp=[]
            for i in range(0,len(num)):
                if num[i]==0:
                    num[i]=1
            for j in range(0,len(num)):
                cp.append(math.log(num[j]/sum(num)))

            list_dish_p=[]
            for dish in list_dish:
                sql="select "+person+" from "+dish
                cur.execute(sql)
                state=False
                for row in cur.fetchall():
                    if type(row[0])==type(1) and operator.eq(dishID,dish)==False:
                        state=True
                if state==True:
                    list_dish_p.append(dish)
            print(list_dish_p)
            rowlist_p=[]
            for dish in list_dish_p:
                sql='select * from '+dish
                cur.execute(sql)
                for row in cur.fetchall():
                    if type(row[2])==type(1.0):
                        rowlist_p.append(list(row)[5:])
            rowlist_pc=[]
            rowlist_pnum=[]
            for row in rowlist_p:
                rs=classify(row)
                rowlist_pc.append(rs[0])
                rowlist_pnum.append(rs[2])
            for i in range(0,len(rowlist_p)):
                wp=[]
                w_c=[]

                _num=rowlist_pnum[i]
                for y in range(0,len(_num)):
                    if _num[y]==0:
                        _num[y]=1
                for j in range(0,len(_num)):
                    wp.append(_num[j]/sum(_num))

                for m in range(0,len(num)):
                    w_c.append([m,[],[]])
                    for n in range(0,len(_num)):
                        w_c[m][1].append(0)

                index=0
                for data in rowlist_pc[i]:
                    if operator.eq(type(data),type(1))==True:
                        for  m in range(0,len(num)):
                            if category[index]==m:
                                for n in range(0,len(_num)):
                                    if data==n:
                                        w_c[m][1][n]=w_c[m][1][n]+1

                for m in range(0,len(num)):
                    all=0
                    for n in range(0,len(_num)):
                        if w_c[m][1][n]==0:
                            w_c[m][1][n]=1
                        all=all+w_c[m][1][n]
                    for n in range(0,len(_num)):
                        w_c[m][2].append(w_c[m][1][n]/all)

                Q0=rowlist_pc[i][personID]
                for j in range(0,len(num)):
                    p=math.log(w_c[j][2][Q0])/math.log(wp[Q0])
                    cp[j]=cp[j]*p
            
            predict_grp=cp.index(max(cp))
            predict.append(str(avg[predict_grp]))
        return predict

    res=bayes_predict(sys.argv[1],sys.argv[2],list_dish)
    fn=os.path.join(os.path.dirname(os.path.abspath('__file__')), 'interchange.txt')
    with open(fn,'r+') as new_file:
        new_file.seek(0)
        new_file.truncate()
        new_file.write(','.join(res))            

            
    conn.commit()
    cur.close()
    conn.close()


