#!/usr/bin/env python
# -*- conding: utf-8 -*-

import pypyodbc
if __name__=="__main__":

    str = 'Driver={Microsoft Access Driver (*.mdb)};DBQ=E:\Database.mdb'
    conn = pypyodbc.win_connect_mdb(str)
    #conn = pypyodbc.connect(str)
    cur = conn.cursor()
    cur.execute("ALTER TABLE tomato_with_egg ADD [Person2] int")
    conn.commit()
    cur.close()
    conn.close()
