import pypyodbc
import operator
import random
import scipy.stats as stats
from xlwt import *
import time

class person:
    def __init__(self,ID=0):
        self.ID=ID
        self.proficiency=stats.norm.rvs(loc=50,scale=15)

class process:
    def __init__(self,dishID,processID,basic_time):
        self.dishID=dishID
        self.processID=processID
        self.basic_time=basic_time
        a=random.uniform(1.1,1.4)  #(a,0) on the proficiency function
        b=random.uniform(0.7,0.9)  #(b,0) on the proficiency function
        sc_p=random.uniform(0.01,0.02) #the distribution scale of the proficiency function
        self.pfunction=[a,b,sc_p]  #the parameters of the proficiency function

if __name__=="__main__":
    conn_sql = 'Driver={Microsoft Access Driver (*.mdb)};DBQ=E:\Database_1.mdb'
    conn = pypyodbc.win_connect_mdb(conn_sql)
    #conn = pypyodbc.connect(str)
    cur = conn.cursor()
    list_dish=[]
    cur.execute("select name from MSysObjects where type=1 and flags=0")
    for table in cur.fetchall():
        list_dish.append(table[0])
    table_id=0
    list_process=[]
    for table in list_dish:
        sql="select * from "+table
        cur.execute(sql)
        for row in cur.fetchall():
            if type(row[2])==type(1.0):
                process_0=process(table_id,row[0],int(row[2]))
                list_process.append(process_0)
        table_id=table_id+1

    def main(personnum,list_process,list_dish):
        list_person=[]
        processnum=len(list_process)
        Loading_Bar=0
        print('Data Generating...')

        for i in range(0,personnum):
            list_person.append(person(i+1))
            for table in list_dish:
                sql="alter table `"+table+"` add [Person"+str(person(i+1).ID)+"] int"
                cur.execute(sql)
        
        for m in range(0,personnum):
            pf=list_person[m].proficiency
            behaviour=stats.norm.rvs(loc=100,scale=15)/100
            for r in range(0,len(list_dish)):
                if random.uniform(0,1)<0.5:
                    for n in range(0,processnum):
                        dishID=list_dish[list_process[n].dishID]
                        print(list_dish.index(dishID),r)
                        if list_dish.index(dishID)==r:
                            basic_time=list_process[n].basic_time
                            a=list_process[n].pfunction[0]
                            b=list_process[n].pfunction[1]
                            sc_p=list_process[n].pfunction[2]
                            processID=list_process[n].processID
                            pfa=a+(b-a)/100*pf+stats.norm.rvs(scale=sc_p)                            
                            time=int(round(basic_time*pfa*behaviour,0))
                            sql="update "+dishID+" set Person"+str(list_person[m].ID)+'='+str(time)+' where ID='+str(processID)
                            print(sql)
                            cur.execute(sql)

    main(50,list_process,list_dish)        

    conn.commit()
    cur.close()
    conn.close()
        
